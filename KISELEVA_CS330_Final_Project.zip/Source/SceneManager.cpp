///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/

SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/

SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/

bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/

void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/

void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/

int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/

int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/

void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/

void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/

void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/

void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/

void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/

void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/

	bool bReturn = false;

	bReturn = CreateGLTexture("../../Utilities/textures/desk_wood.jpg", "wood");
	bReturn = CreateGLTexture("../../Utilities/textures/starry_sky.jpg", "monitor");
	bReturn = CreateGLTexture("../../Utilities/textures/wall.jpg", "wall");
	bReturn = CreateGLTexture("../../Utilities/textures/stainless.jpg", "laptop");
	bReturn = CreateGLTexture("../../Utilities/textures/keyboard.jpg", "keyboard");
	bReturn = CreateGLTexture("../../Utilities/textures/glass.jpg", "lamp_top");
	bReturn = CreateGLTexture("../../Utilities/textures/sky.jpg", "picture");
	bReturn = CreateGLTexture("../../Utilities/textures/pink_quartz.jpg", "mug");
	bReturn = CreateGLTexture("../../Utilities/textures/coffee.jpg", "coffee");
	bReturn = CreateGLTexture("../../Utilities/textures/pink_leather.jpg", "notebook");
	bReturn = CreateGLTexture("../../Utilities/textures/black_texture.jpg", "black_texture");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/

void SceneManager::DefineObjectMaterials()
{
	/*** STUDENTS - add the code BELOW for defining object materials. ***/
	/*** There is no limit to the number of object materials that can ***/
	/*** be defined. Refer to the code in the OpenGL Sample for help  ***/

	// Defining metal material features
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	metalMaterial.ambientStrength = 0.4f;
	metalMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	metalMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
	metalMaterial.shininess = 10.0;
	metalMaterial.tag = "metal";
	m_objectMaterials.push_back(metalMaterial);

	// Defining wood material features
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
	woodMaterial.ambientStrength = 0.2f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 3.0;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// Defining drywall material features
	OBJECT_MATERIAL drywallMaterial;
	drywallMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	drywallMaterial.ambientStrength = 0.4f;
	drywallMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	drywallMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	drywallMaterial.shininess = 1.0;
	drywallMaterial.tag = "drywall";
	m_objectMaterials.push_back(drywallMaterial);

	// Defining glass material features
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	glassMaterial.ambientStrength = 0.3f;
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	glassMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	glassMaterial.shininess = 20.0;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);

	// Defining plastic material features
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	plasticMaterial.ambientStrength = 0.3f;
	plasticMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
	plasticMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	plasticMaterial.shininess = 5.0;
	plasticMaterial.tag = "plastic";
	m_objectMaterials.push_back(plasticMaterial);

	// Defining ceramics material features
	OBJECT_MATERIAL ceramicsMaterial;
	ceramicsMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	ceramicsMaterial.ambientStrength = 0.4f;
	ceramicsMaterial.diffuseColor = glm::vec3(0.4f, 0.3f, 0.2f);
	ceramicsMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	ceramicsMaterial.shininess = 10.0;
	ceramicsMaterial.tag = "ceramics";
	m_objectMaterials.push_back(ceramicsMaterial);

	// Defining leather material features
	OBJECT_MATERIAL leatherMaterial;
	leatherMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	leatherMaterial.ambientStrength = 0.4f;
	leatherMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	leatherMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	leatherMaterial.shininess = 5.0;
	leatherMaterial.tag = "leather";
	m_objectMaterials.push_back(leatherMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/

void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting, if no light sources have
	// been added then the display window will be black - to use the 
	// default OpenGL lighting then comment out the following line
	//m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/*** STUDENTS - add the code BELOW for setting up light sources ***/
	/*** Up to four light sources can be defined. Refer to the code ***/
	/*** in the OpenGL Sample for help                              ***/

	// Light #1
	m_pShaderManager->setVec3Value("lightSources[0].position", 0.0f, 0.0f, 7.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 12.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.05f);

	// Light #2
	m_pShaderManager->setVec3Value("lightSources[1].position", 7.0f, 6.0f, 7.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 12.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.05f);

	// Light #3
	m_pShaderManager->setVec3Value("lightSources[2].position", -7.0f, 6.0f, 7.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 12.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.05f);

	// Light #4
	m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, 0.0f, 10.0f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 12.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.05f);

	m_pShaderManager->setBoolValue("bUseLighting", true);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/

void SceneManager::PrepareScene()
{
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadSphereMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/

void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	/***************************************************************/
	/***           Working with a PLANE mesh - TABLE             ***/
	/***************************************************************/

	// set the XYZ scale for the PLANE mesh
	scaleXYZ = glm::vec3(16.0f, 0.0f, 8.0f);

	// set the XYZ rotation for the PLANE mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the PLANE mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn PLANE mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set PLANE texture to brown wood
	SetShaderTexture("wood");

	// set PLANE material to wood
	SetShaderMaterial("wood");

	// draw the PLANE mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	

	/***************************************************************/
	/*** Working with a TAPERED CYLINDER mesh - LAMP BOTTOM PART ***/
	/***************************************************************/

	// set the XYZ scale for the TAPERED CYLINDER mesh
	scaleXYZ = glm::vec3(2.5f, 5.0f, 2.0f);

	// set the XYZ rotation for the TAPERED CYLINDER mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the TAPERED CYLINDER mesh
	positionXYZ = glm::vec3(7.0f, 0.0f, -3.0f);

	// set the transformations into memory to be used on the drawn TAPERED CYLINDER mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set TAPERED CYLINDER texture to black plastic
	SetShaderTexture("black_texture");

	// set TAPERED CYLINDER material to plastic
	SetShaderMaterial("plastic");

	// draw the TAPERED CYLINDER mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();
	
	/***************************************************************/
	/***       Working with a CYLINDER mesh - LAMP TOP PART      ***/
	/***************************************************************/

	// set the XYZ scale for the CYLINDER mesh
	scaleXYZ = glm::vec3(3.0f, 5.0f, 2.0f);

	// set the XYZ rotation for the CYLINDER mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the CYLINDER mesh
	positionXYZ = glm::vec3(7.0f, 5.0f, -3.0f);

	// set the transformations into memory to be used on the drawn CYLINDER mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set CYLINDER texture to glass
	SetShaderTexture("lamp_top");

	// set CYLINDER material to glass
	SetShaderMaterial("glass");

	// draw the CYLINDER mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/***************************************************************/
	/***        Working with a CYLINDER mesh - COFFE MUG         ***/ 
	/***************************************************************/

	// set the XYZ scale for the CYLINDER mesh
	scaleXYZ = glm::vec3(1.0f, 2.0f, 1.0f);

	// set the XYZ rotation for the CYLINDER mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the CYLINDER mesh
	positionXYZ = glm::vec3(8.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn CYLINDER mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set CYLINDER texture to pink ceramics
	SetShaderTexture("mug");

	// set CYLINDER material to ceramics
	SetShaderMaterial("ceramics");

	// draw the CYLINDER mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/***************************************************************/
	/***     Working with a CYLINDER mesh - COFFE IN THE MUG     ***/
	/***************************************************************/

	// set the XYZ scale for the CYLINDER mesh
	scaleXYZ = glm::vec3(0.8f, 1.7f, 0.8f);

	// set the XYZ rotation for the CYLINDER mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the CYLINDER mesh
	positionXYZ = glm::vec3(8.0f, 0.31f, 0.0f);

	// set the transformations into memory to be used on the drawn CYLINDER mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set CYLINDER texture to coffee
	SetShaderTexture("coffee");

	// draw the CYLINDER mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/***************************************************************/
	/***     Working with a TORUS mesh - COFFE MUG'S HANDLE      ***/
	/***************************************************************/

    // set the XYZ scale for the TORUS mesh
	scaleXYZ = glm::vec3(0.5f, 0.7f, 0.5f);

	// set the XYZ rotation for the TORUS mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the TORUS mesh
	positionXYZ = glm::vec3(9.0f, 1.0f, 0.0f);

	// set the transformations into memory to be used on the drawn TORUS mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set TORUS texture to pink ceramics
	SetShaderTexture("mug");

	// set TORUS material to ceramics
	SetShaderMaterial("ceramics");

	// draw the TORUS mesh with transformation values
	m_basicMeshes->DrawTorusMesh();

	/***************************************************************/
	/***        Working with a BOX mesh - LAPTOP TOP PART        ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(10.0f, 6.0f, 0.2f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(-2.0f, 3.0f, -2.0f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to light gray metal
	SetShaderTexture("laptop");

	// set BOX material to metal
	SetShaderMaterial("metal");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***       Working with a BOX mesh - LAPTOP BOTTOM PART      ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(10.0f, 6.0f, 0.2f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(-2.0f, 0.1f, 1.0f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to light gray metal
	SetShaderTexture("laptop");

	// set BOX material to metal
	SetShaderMaterial("metal");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***            Working with a BOX mesh - KEYBOARD           ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(8.0f, 3.0f, 0.1f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(-2.0f, 0.2f, 1.7f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to light gray metal
	SetShaderTexture("keyboard");

	// set BOX material to metal
	SetShaderMaterial("metal");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***            Working with a PLANE mesh - WALL             ***/
	/***************************************************************/

	// set the XYZ scale for the PLANE mesh
	scaleXYZ = glm::vec3(16.0f, 0.0f, 8.0f);

	// set the XYZ rotation for the PLANE mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the PLANE mesh
	positionXYZ = glm::vec3(0.0f, 8.0f, -8.0f);

	// set the transformations into memory to be used on the drawn PLANE mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set PLANE texture to whitish drywall
	SetShaderTexture("wall");

	// set PLANE material to drywall
	SetShaderMaterial("drywall");

	// draw the PLANE mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/***************************************************************/
	/***          Working with a BOX mesh - PICTURE FRAME        ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(8.0f, 8.0f, 1.0f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(4.0f, 10.0f, -7.5f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to black plastic
	SetShaderTexture("black_texture");

	// set BOX material to plastic
	SetShaderMaterial("plastic");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***            Working with a BOX mesh - PICTURE            ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(7.0f, 7.0f, 0.9f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(4.0f, 10.0f, -7.4f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to clouds picture
	SetShaderTexture("picture");

	// set BOX material to glass
	SetShaderMaterial("glass");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***         Working with a BOX mesh - LAPTOP SCREEN         ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(9.0f, 5.0f, 0.05f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(-2.0f, 3.0f, -1.9f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to starry sky picture
	SetShaderTexture("monitor");

	// set BOX material to glass
	SetShaderMaterial("glass");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***           Working with a SPHERE mesh - MOUSE            ***/
	/***************************************************************/

	// set the XYZ scale for the SPHERE mesh
	scaleXYZ = glm::vec3(0.6f, 0.7f, 0.2f);

	// set the XYZ rotation for the SPHERE mesh
	XrotationDegrees = -90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the SPHERE mesh
	positionXYZ = glm::vec3(5.0f, 0.2f, 3.0f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set SPHERE texture to light gray metal
	SetShaderTexture("laptop");

	// set SPHERE material to metal
	SetShaderMaterial("metal");

	// draw the SPHERE mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	/***************************************************************/
	/***         Working with a SPHERE mesh - MOUSE WHEEL        ***/
	/***************************************************************/

	// set the XYZ scale for the SPHERE mesh
	scaleXYZ = glm::vec3(0.1f, 0.1f, 0.1f);

	// set the XYZ rotation for the SPHERE mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the SPHERE mesh
	positionXYZ = glm::vec3(5.0f, 0.4f, 2.8f);

	// set the transformations into memory to be used on the drawn SPHERE mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set SPHERE color to black
	SetShaderColor(0.000, 0.000, 0.000, 1.000);

	// draw the SPHERE mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	/***************************************************************/
	/***           Working with a BOX mesh - NOTEBOOK            ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(3.0f, 3.0f, 0.2f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(-1.0f, 0.1f, 6.0f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to pink leather
	SetShaderTexture("notebook");

	// set BOX material to leather
	SetShaderMaterial("leather");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***         Working with a BOX mesh - NOTEPAD PAGES         ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(2.85f, 3.05f, 0.1f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(-0.9f, 0.1f, 6.0f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the BOX color to white
	SetShaderColor(1.000, 1.000, 1.000, 1.000);

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***            Working with a SPHERE mesh - PEN             ***/
	/***************************************************************/

	// set the XYZ scale for the SPHERE mesh
	scaleXYZ = glm::vec3(0.075f, 1.0f, 0.075f);

	// set the XYZ rotation for the SPHERE mesh
	XrotationDegrees = -90.0f;
	YrotationDegrees = 30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the SPHERE mesh
	positionXYZ = glm::vec3(2.0f, 0.1f, 6.0f);

	// set the transformations into memory to be used on the drawn SPHERE mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set SPHERE texture to black plastic
	SetShaderTexture("black_texture");

	// set SPHERE material to plastic
	SetShaderMaterial("plastic");

	// draw the SPHERE mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	/*****************************************************************/
	/*** Working with a TORUS mesh - RIGHT PART OF THE GLASS FRAME ***/
	/*****************************************************************/

	// set the XYZ scale for the TORUS mesh
	scaleXYZ = glm::vec3(0.5f, 0.25f, 0.2f);

	// set the XYZ rotation for the TORUS mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the TORUS mesh
	positionXYZ = glm::vec3(-4.0f, 0.28f, 7.2f);

	// set the transformations into memory to be used on the drawn TORUS mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set TORUS texture to black plastic
	SetShaderTexture("black_texture");

	// set TORUS material to plastic
	SetShaderMaterial("plastic");

	// draw the TORUS mesh with transformation values
	m_basicMeshes->DrawTorusMesh();

	/*****************************************************************/
	/*** Working with a TORUS mesh - LEFT PART OF THE GLASS FRAME  ***/
	/*****************************************************************/

	// set the XYZ scale for the TORUS mesh
	scaleXYZ = glm::vec3(0.5f, 0.25f, 0.2f);

	// set the XYZ rotation for the TORUS mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the TORUS mesh
	positionXYZ = glm::vec3(-5.2f, 0.28f, 6.5f);

	// set the transformations into memory to be used on the drawn TORUS mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set TORUS texture to black plastic
	SetShaderTexture("black_texture");

	// set TORUS material to plastic
	SetShaderMaterial("plastic");

	// draw the TORUS mesh with transformation values
	m_basicMeshes->DrawTorusMesh();

	/***************************************************************/
	/***        Working with a BOX mesh - GLASSES BRIDGE         ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(0.3f, 0.05f, 0.05f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(-4.6f, 0.2f, 6.85f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to black plastic
	SetShaderTexture("black_texture");

	// set BOX material to plastic
	SetShaderMaterial("plastic");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***     Working with a BOX mesh - GLASSES RIGHT TEMPLE      ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(0.05f, 1.0f, 0.05f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(-3.55f, 0.05f, 6.9f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to black plastic
	SetShaderTexture("black_texture");

	// set BOX material to plastic
	SetShaderMaterial("plastic");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***      Working with a BOX mesh - GLASSES LEFT TEMPLE      ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(0.05f, 1.0f, 0.05f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(-5.1f, 0.05f, 5.95f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to black plastic
	SetShaderTexture("black_texture");

	// set BOX material to plastic
	SetShaderMaterial("plastic");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***   Working with a BOX mesh - GLASSES RIGHT TEMPLE TIP    ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(0.05f, 0.5f, 0.05f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = 30.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(-3.2f, 0.11f, 6.25f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to black plastic
	SetShaderTexture("black_texture");

	// set BOX material to plastic
	SetShaderMaterial("plastic");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************/
	/***    Working with a BOX mesh - GLASSES LEFT TEMPLE TIP    ***/
	/***************************************************************/

	// set the XYZ scale for the BOX mesh
	scaleXYZ = glm::vec3(0.05f, 0.5f, 0.05f);

	// set the XYZ rotation for the BOX mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = 30.0f;

	// set the XYZ position for the BOX mesh
	positionXYZ = glm::vec3(-4.75f, 0.11f, 5.33f);

	// set the transformations into memory to be used on the drawn BOX mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set BOX texture to black plastic
	SetShaderTexture("black_texture");

	// set BOX material to plastic
	SetShaderMaterial("plastic");

	// draw the BOX mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
}


